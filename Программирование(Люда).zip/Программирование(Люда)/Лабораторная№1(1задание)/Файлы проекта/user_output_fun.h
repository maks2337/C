﻿#pragma once
// Объявление функции вывода результата OutputData; val — вычисленный объём конуса.
void OutputData(double val);