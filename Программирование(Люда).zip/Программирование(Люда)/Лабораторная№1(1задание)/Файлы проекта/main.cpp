﻿// подключение библиотек
#include <iostream> 
// подключение файлов проекта
#include "user_fun.h" 
#include "user_output_fun.h"
#include "user_input_fun.h"

int main()
{
	
	setlocale(LC_ALL, "ru"); // Устанавливаем русскую раскладку для работы с текстом в консоли.
	// Переменные для высоты и радиуса основания конуса.
	double height = 0;
	double radius = 0;
	// Функция заполняет переменные через ссылки, проверяя положительность размеров.
	InputData(radius, height);
	// Передаём вычисленный объём непосредственно в функцию вывода.
	OutputData(conusVolume(radius, height));
	return 0;
    std::cin.ignore().get();
}
