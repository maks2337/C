﻿// Подключение заголовочного файла и библиотек
#include "user_fun.h"
#include <cmath>

// Вычисляем объём конуса по радиусу основания и высоте.
double conusVolume(double radius, double height)
{
    // Арктангенс единицы равен четверти числа пи; умножением на 4 получаем пи.
    double pi = std::atan(1.0) * 4;
    // Формула объёма: V = пи * r^2 * h / 3.
    return radius * radius * height * pi / 3.0;
}
