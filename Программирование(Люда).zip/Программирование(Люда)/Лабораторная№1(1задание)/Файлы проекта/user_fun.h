﻿#pragma once
// Объявление функции conusVolume
double conusVolume(double radius, double height);