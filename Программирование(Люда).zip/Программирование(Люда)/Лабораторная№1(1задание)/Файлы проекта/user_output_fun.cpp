﻿#include "user_output_fun.h"
#include <iostream>

// Выводим переданное значение объёма конуса в консоль.
void OutputData(double val)
{
	// std::endl переводит строку и сбрасывает буфер вывода.
	std::cout << "Объем конуса равен: " << val << std::endl;
}
