﻿#pragma once
// Объявление функции InputData
void InputData(double& radius, double& height);