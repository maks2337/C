#include "ConsoleView.h"
#include <iostream>

void ConsoleView::Notify(const GuessResult& result) {
    {
        // Общий результат защищён от одновременного чтения и записи.
        std::lock_guard<std::mutex> lock(mutex);
        latest = result;
        ready = true;
    }
    changed.notify_one();
}

GuessResult ConsoleView::WaitForResult() {
    std::unique_lock<std::mutex> lock(mutex);
    changed.wait(lock, [this] { return ready; });
    ready = false;
    return latest;
}

void ConsoleView::Render(const GuessResult& result) const {
    if (result.error) {
        std::cout << "[ERROR] ";
    }
    std::cout << result.message << '\n';
    if (!result.error) {
        std::cout << "Количество попыток: " << result.attempts << "\n\n";
    }
}
