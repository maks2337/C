#include "ConsoleView.h"
#include "GameViewModel.h"
#include <iostream>
#include <memory>
#include <string>
#ifdef _WIN32
#include <Windows.h>
#endif

int main() {
#ifdef _WIN32
    // Исходники и консоль используют UTF-8 для корректного отображения русского текста.
    SetConsoleCP(CP_UTF8);
    SetConsoleOutputCP(CP_UTF8);
#endif
    int exitCode = 0;
    try {
        auto model = std::make_shared<Game>();
        // View создаётся раньше ViewModel и переживает завершение рабочего потока.
        ConsoleView view;
        GameViewModel viewModel(model, [&view](const GuessResult& result) {
            view.Notify(result);
        });

        std::cout << "Игра «Угадай число»\nЗагадано целое число от 1 до 100.\n"
                     "Пустая строка (Enter) — завершить игру.\n\n";
        std::string input;
        while (true) {
            std::cout << "Ваша попытка: " << std::flush;
            if (!std::getline(std::cin, input) || input.empty()) {
                break;
            }
            viewModel.SubmitGuess(input);
            // Для пошаговой игры ждём ответ без активного опроса.
            // Разбор ввода и проверка числа при этом выполняются в рабочем потоке.
            const auto result = view.WaitForResult();
            view.Render(result);
            if (result.won) {
                break;
            }
        }
        viewModel.Stop();
        std::cout << "Игра завершена.\n";
    } catch (const std::exception& error) {
        // В том числе обрабатываем std::system_error при невозможности создать поток.
        std::cerr << "[ERROR] " << error.what() << '\n';
        exitCode = 1;
    } catch (...) {
        std::cerr << "[ERROR] Неизвестная ошибка приложения.\n";
        exitCode = 1;
    }

    // Пауза позволяет прочитать результат при запуске exe двойным щелчком.
    // При перенаправленном вводе, закончившемся EOF, программа не зависает.
    if (std::cin.good()) {
        std::cout << "Нажмите Enter для выхода..." << std::flush;
        std::string line;
        std::getline(std::cin, line);
    }
    return exitCode;
}
