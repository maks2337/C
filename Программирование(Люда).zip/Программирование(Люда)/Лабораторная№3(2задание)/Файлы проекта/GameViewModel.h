#pragma once
#include "Game.h"
#include <condition_variable>
#include <functional>
#include <memory>
#include <mutex>
#include <queue>
#include <string>
#include <thread>

// ViewModel связывает модель с View и проверяет введённые строки в отдельном потоке.
class GameViewModel {
public:
    using Notification = std::function<void(const GuessResult&)>;
    GameViewModel(std::shared_ptr<Game> model, Notification onChanged);
    ~GameViewModel();
    GameViewModel(const GameViewModel&) = delete;
    GameViewModel& operator=(const GameViewModel&) = delete;
    void SubmitGuess(std::string input);
    void Stop();

private:
    void Run();
    std::shared_ptr<Game> model;
    Notification onChanged;
    std::mutex mutex;
    std::condition_variable wakeUp;
    std::queue<std::string> inputs;
    bool stopping = false;
    std::thread worker;
};
