#pragma once
#include <random>
#include <string>

// Результат одной попытки передаётся из модели в представление через ViewModel.
struct GuessResult {
    int attempts = 0;
    bool won = false;
    bool error = false;
    std::string message;
};

// Model: правила игры без ввода, вывода и управления потоками.
// После запуска игры к модели обращается только рабочий поток ViewModel.
class Game {
public:
    Game();
    explicit Game(int secret); // Позволяет проверять игру с заранее известным числом.
    GuessResult CheckGuess(int guess);

private:
    int secretNumber;
    int attempts = 0;
};
