#include "Game.h"
#include <stdexcept>

Game::Game() : secretNumber(0) {
    // Равномерно выбираем целое число в диапазоне от 1 до 100 включительно.
    std::mt19937 generator(std::random_device{}());
    secretNumber = std::uniform_int_distribution<int>(1, 100)(generator);
}

Game::Game(int secret) : secretNumber(secret) {
    if (secret < 1 || secret > 100) {
        throw std::invalid_argument("Секретное число должно быть от 1 до 100.");
    }
}

GuessResult Game::CheckGuess(int guess) {
    if (guess < 1 || guess > 100) {
        return {attempts, false, true, "Введите целое число от 1 до 100."};
    }
    ++attempts;
    if (guess < secretNumber) {
        return {attempts, false, false, "Загаданное число больше."};
    }
    if (guess > secretNumber) {
        return {attempts, false, false, "Загаданное число меньше."};
    }
    return {attempts, true, false, "Поздравляем! Вы угадали число."};
}
