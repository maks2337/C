#pragma once
#include "Game.h"
#include <condition_variable>
#include <mutex>

// View: весь консольный ввод и вывод выполняются в главном потоке.
class ConsoleView {
public:
    void Notify(const GuessResult& result);
    GuessResult WaitForResult();
    void Render(const GuessResult& result) const;

private:
    std::mutex mutex;
    std::condition_variable changed;
    GuessResult latest;
    bool ready = false;
};
