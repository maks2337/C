#include "GameViewModel.h"
#include <sstream>
#include <stdexcept>
#include <utility>

GameViewModel::GameViewModel(std::shared_ptr<Game> model, Notification onChanged)
    : model(std::move(model)), onChanged(std::move(onChanged)) {
    if (!this->model || !this->onChanged) {
        throw std::invalid_argument("Не заданы модель или обработчик уведомлений.");
    }
    // Ошибка создания потока (std::system_error) передаётся обработчику в main.
    // Поток запускается после инициализации всех полей объекта.
    worker = std::thread(&GameViewModel::Run, this);
}

GameViewModel::~GameViewModel() {
    Stop();
}

void GameViewModel::SubmitGuess(std::string input) {
    {
        std::lock_guard<std::mutex> lock(mutex);
        if (stopping) {
            throw std::runtime_error("Игра уже остановлена.");
        }
        inputs.push(std::move(input));
    }
    wakeUp.notify_one();
}

void GameViewModel::Stop() {
    {
        std::lock_guard<std::mutex> lock(mutex);
        stopping = true;
    }
    // Пробуждаем поток, даже если он ожидает новую попытку, и дожидаемся его выхода.
    wakeUp.notify_all();
    if (worker.joinable()) {
        worker.join();
    }
}

void GameViewModel::Run() {
    int attempts = 0;
    while (true) {
        std::string input;
        {
            std::unique_lock<std::mutex> lock(mutex);
            // Ожидание без активного опроса. Предикат защищает от ложных пробуждений.
            wakeUp.wait(lock, [this] { return stopping || !inputs.empty(); });
            if (stopping) {
                return;
            }
            input = std::move(inputs.front());
            inputs.pop();
        }

        GuessResult result;
        try {
            // Проверяем всю строку: «12abc», дроби и слишком большие числа недопустимы.
            std::istringstream stream(input);
            int guess = 0;
            if (!(stream >> guess) || !(stream >> std::ws).eof()) {
                result = {attempts, false, true, "Введите целое число от 1 до 100."};
            } else {
                result = model->CheckGuess(guess);
                attempts = result.attempts;
            }
        } catch (const std::exception& error) {
            result = {attempts, false, true, std::string("Ошибка проверки: ") + error.what()};
        } catch (...) {
            result = {attempts, false, true, "Неизвестная ошибка рабочего потока."};
        }

        // Уведомляем View вне блокировки: обработчик только сохраняет результат.
        // Консоль обновляет главный поток, а не рабочий.
        onChanged(result);
        if (result.won) {
            std::lock_guard<std::mutex> lock(mutex);
            stopping = true;
            return;
        }
    }
}
