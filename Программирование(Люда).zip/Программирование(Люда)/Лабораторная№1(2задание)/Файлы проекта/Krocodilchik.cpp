﻿// Подключаем заголовочный файл и библитеку
#include "Krocodilchik.h"
#include <iostream>

// Реализация конструктора: создаём питомца с переданными характеристиками.
// В записи breed(breed) слева указано поле, а в скобках — параметр конструктора.
krocodilchik::krocodilchik(const std::string& breed, double height,
    double weight, int age)
    : breed(breed), height(height), weight(weight), age(age) {
}
// Последовательно выводим породу, рост, вес и возраст без изменения объекта.
// std::endl завершает строку и сбрасывает буфер вывода.
void krocodilchik::printInfo() const{
    std::cout << "Порода питомца: " << breed << std::endl;
    std::cout << "Рост питомца: " << height << std::endl;
    std::cout << "Вес питомца: " << weight << std::endl;
    std::cout << "Возраст питомца:" << age << std::endl;
}
// Метод предоставляет доступ к значению закрытого поля age.
int krocodilchik::getAge() const {
    return age;
}

// Изменяем возраст при наступлении дня рождения.
void krocodilchik::birthday()
{
    // Оператор ++ увеличивает значение age на единицу.
    ++age;
}
