﻿#pragma once
// подключение заголвока
#include "Cylinder.h"
// Приближённое значение числа пи для вычисления объёма цилиндра.
#define PI 3.1415


// Конструктор базового класса задаёт начальные нулевые размеры.
Cylinder::Cylinder() : Shape(){
}
// Инициализируем размеры через конструктор Shape с проверкой их положительности.
Cylinder::Cylinder(double radius, double height) : Shape(radius, height) {
}
// Объём цилиндра равен площади основания, умноженной на высоту: V = пи * r^2 * h.
double Cylinder::calculateVolume() const {
	return PI * getRadius() * getRadius() * getHeight();
}
// Возвращаем название фигуры для общего метода вывода базового класса.
std::string Cylinder::getName() const {
	return "Цилиндр";
}