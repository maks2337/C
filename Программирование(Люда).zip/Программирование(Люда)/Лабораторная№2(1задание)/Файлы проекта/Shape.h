﻿#pragma once
// Подключение заголовка <string> для использования std::string в методах класса.
#include <string>

// Абстрактный базовый класс фигур с радиусом основания и высотой.
class Shape {
private:
	// Закрытые размеры доступны извне только через методы класса.
	double radius;
	double height;
public:
	// Конструктор без параметров задаёт нулевые размеры.
	Shape();
	// Конструктор с параметрами проверяет размеры через методы установки.
	Shape(double radius, double height);
	// Виртуальный деструктор обеспечивает корректное удаление наследников через Shape*.
	virtual ~Shape() = default;

	// Методы чтения размеров; const запрещает изменение состояния объекта.
	double getRadius() const;
	double getHeight() const;

	// Методы установки размеров отклоняют нулевые и отрицательные значения.
	void setRadius(double radius);
	void setHeight(double height);

	// Чисто виртуальные методы: каждый наследник задаёт свою формулу и название.
	virtual double calculateVolume() const = 0;
	virtual std::string getName() const = 0;

	// Общий вывод результата использует реализации виртуальных методов наследника.
	void printResult() const;
};