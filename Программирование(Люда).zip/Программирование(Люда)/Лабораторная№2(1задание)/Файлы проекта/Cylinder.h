﻿#pragma once
// Подключение базового класса Shape для наследования размеров и методов.
#include "Shape.h"

// Цилиндр наследует хранение размеров и методы работы с ними от Shape.
class Cylinder : public Shape{
public:
	// Конструктор без параметров создаёт фигуру с нулевыми размерами.
	Cylinder();
	// Конструктор с параметрами передаёт размеры базовому классу для проверки.
	Cylinder(double radius, double height);

	// Собственная формула объёма; override подтверждает переопределение метода базы.
	double calculateVolume() const override;
	// Название цилиндра для вывода результата; const означает отсутствие изменений объекта.
	std::string getName() const override;
};