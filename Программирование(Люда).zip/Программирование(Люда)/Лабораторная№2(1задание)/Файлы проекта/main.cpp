﻿// Подключаем заголовочные файлы классов Shape, Conus и Cylinder и необходимые стандартные библиотеки.
#include <iostream>
#include <limits>
#include <string>
#include <Windows.h>
#include "Shape.h"
#include "Conus.h"
#include "Cylinder.h"


// Точка входа: вводим размеры конуса и цилиндра, затем выводим их объёмы.
int main()
{
	// Настраиваем кодировку UTF-8 для ввода и вывода консоли Windows.
	SetConsoleCP(CP_UTF8);
	SetConsoleOutputCP(CP_UTF8);


	// Отдельные переменные хранят высоту и радиус каждой фигуры.
	double heightcon = 0.0;
	double radiuscon = 0.0;
	double heightcyl = 0.0;
	double radiuscyl = 0.0;
	
	// Создаём фигуры конструкторами без параметров; размеры пока равны нулю.
	Cylinder cylinder;
	Conus conus;

	std::cout << "Введите данные для конуса: " << std::endl;
	std::cout << "Введите высоту конуса: ";
	// Читаем высоту конуса.
	std::cin >> heightcon;
	// Методы установки проверяют положительность размеров и сохраняют их в объекте.
	// Исключения и ошибки чтения потока в main не обрабатываются.
	conus.setHeight(heightcon);
	std::cout << "Введите радиус конуса: ";
	// Читаем и устанавливаем радиус основания конуса.
	std::cin >> radiuscon;
	conus.setRadius(radiuscon);
	std::cout << "Введите данные для цилиндра: " << std::endl;
	std::cout << "Введите высоту цилиндра: ";
	// Читаем и устанавливаем высоту цилиндра.
	std::cin >> heightcyl;
	cylinder.setHeight(heightcyl);
	std::cout << "Введите радиус цилиндра: ";
	// Читаем и устанавливаем радиус основания цилиндра.
	std::cin >> radiuscyl;
	cylinder.setRadius(radiuscyl);
	// Унаследованный метод вывода использует собственную формулу каждой фигуры.
	conus.printResult();
	cylinder.printResult();
	std::cin.ignore().get();// Ждём нового нажатия Enter перед завершением программы.
	return 0;
}
