﻿#pragma once
// Подключение заголовочного файла
#include "Conus.h"
// Приближённое значение числа пи для расчёта объёма конуса.
#define PI 3.1415


// Вызываем конструктор Shape без параметров для инициализации размеров нулями.
Conus::Conus() : Shape() {
}

// Передаём размеры конструктору базового класса, который проверяет их значения.
Conus::Conus(double radius, double height)
    : Shape(radius, height) {
}
// Объём конуса: V = пи * r^2 * h / 3.
// Закрытые поля базового класса читаем через getRadius() и getHeight().
double Conus::calculateVolume() const {
    return PI * getRadius() * getRadius() * getHeight() / 3.0;
}
// Возвращаем название конуса для вывода в Shape::printResult().
std::string Conus::getName() const {
    return "Конус";
}
