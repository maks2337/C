﻿#pragma once
// Подключение базового класса Shape для наследования размеров и методов.
#include "Shape.h"

// Конус наследует хранение размеров и методы работы с ними от Shape.
class Conus : public Shape{
public:
	// Создание конуса с нулевыми размерами через конструктор базового класса.
	Conus();
	// Создание конуса с заданными радиусом основания и высотой.
	Conus(double radius, double height);

	// Переопределение вычисления объёма; override проверяет совпадение с методом базы.
	double calculateVolume() const override;
	// Возвращает название фигуры для общего метода вывода printResult().
	std::string getName() const override;
};