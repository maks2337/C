﻿// Подключаем заголовочный файл и необходимые стандартные библиотеки.
#include "Shape.h"
#include <iostream>
#include <iomanip>
#include <stdexcept>

// Список инициализации задаёт нули; проверка положительности здесь не вызывается.
Shape::Shape() : radius(0.0), height(0.0) {
}
// Сначала обнуляем поля, затем устанавливаем переданные размеры с проверками.
Shape::Shape(double radius, double height) : radius(0.0), height(0.0) {
    setRadius(radius);
    setHeight(height);
}

// Возвращаем радиус, не изменяя объект.
double Shape::getRadius() const {
    return radius;
}

// Возвращаем высоту, не изменяя объект.
double Shape::getHeight() const {
    return height;
}

// Устанавливаем радиус только после проверки допустимости значения.
void Shape::setRadius(double radius) {
    // При нулевом или отрицательном радиусе выбрасываем исключение.
    if (radius <= 0.0) {
        throw std::invalid_argument("Радиус должен быть больше нуля");
    }

    // this->radius — поле объекта, radius справа — параметр метода.
    this->radius = radius;
}

// Аналогично проверяем и сохраняем высоту фигуры.
void Shape::setHeight(double height) {
    // Исключение прерывает метод до присваивания недопустимого значения.
    if (height <= 0.0) {
        throw std::invalid_argument("Высота должна быть больше нуля");
    }

    // Ключевое слово this отличает поле объекта от одноимённого параметра.
    this->height = height;
}

// Виртуальные вызовы выбирают название и формулу объёма конкретного наследника.
// fixed и setprecision(3) задают вывод трёх цифр после десятичного разделителя.
void Shape::printResult() const {
    std::cout << "Объем фигуры \"" << getName() << "\": "
        << std::fixed << std::setprecision(3)
        << calculateVolume() << " куб. ед.\n";
}