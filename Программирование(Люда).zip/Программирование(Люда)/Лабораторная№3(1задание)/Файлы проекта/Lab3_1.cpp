﻿#include <iostream>
#include <stdexcept>
#include <cstddef>

template <typename T>
class DynamicArray {
private:
    T* data;           // Указатель на элементы массива
    std::size_t size; // Количество элементов

public:
    // Конструктор: создаёт массив заданного размера
    explicit DynamicArray(std::size_t arraySize)
        : data(new T[arraySize]{}), size(arraySize) {
    }

    // Запрещаем копирование, чтобы избежать двойного удаления памяти
    DynamicArray(const DynamicArray&) = delete;
    DynamicArray& operator=(const DynamicArray&) = delete;

    // Деструктор: освобождает выделенную память
    ~DynamicArray() {
        delete[] data;
    }

    // Получение элемента по индексу
    const T& get(std::size_t index) const {
        if (index >= size) {
            throw std::out_of_range("Индекс выходит за границы массива");
        }

        return data[index];
    }

    // Установка элемента по индексу
    void set(std::size_t index, const T& value) {
        if (index >= size) {
            throw std::out_of_range("Индекс выходит за границы массива");
        }

        data[index] = value;
    }

    // Получение размера массива
    std::size_t getSize() const {
        return size;
    }
};

int main() {
    setlocale(LC_ALL, "Russian");
    // Создаём массив из трёх целых чисел
    DynamicArray<int> numbers(3);

    numbers.set(0, 10);
    numbers.set(1, 20);
    numbers.set(2, 30);

    std::cout << "Элемент с индексом 1: "
        << numbers.get(1) << '\n';

    // Изменяем второй элемент
    numbers.set(1, 100);

    std::cout << "Массив после изменения: ";

    for (std::size_t i = 0; i < numbers.getSize(); ++i) {
        std::cout << numbers.get(i) << ' ';
    }

    std::cout << '\n';
	std::cin.ignore().get();
    return 0;
}